$(document).ready(function() {
    $('#saveMenu').on('click', function () {
        submit(save);
    });
});